phonegapresources
=================

code to following along with my YouTube Phonegap tutorial youtube.com/rubicks33
